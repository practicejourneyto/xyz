# Databricks notebook source
df10 = spark.read.format("delta").load("dbfs:/user/hive/warehouse/college.db/students")
display(df10)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS college;
# MAGIC USE college;
# MAGIC CREATE TABLE faculty (FacultyID INT,
# MAGIC                       Firstname varchar(50),
# MAGIC                       Lastname varchar(50),
# MAGIC                       Department varchar(50),
# MAGIC                       Age int,
# MAGIC                       Salary Float);

# COMMAND ----------


df11 = spark.read.format("delta").load("dbfs:/user/hive/warehouse/college.db/faculty")
display(df11)

# COMMAND ----------

# MAGIC %md
# MAGIC # Transformation Methods
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## select

# COMMAND ----------

df11.select("Firstname","Lastname").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## filter

# COMMAND ----------

df11.filter(df11.Age>40).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##groupby

# COMMAND ----------

df11.groupBy("Department").count().show()

# COMMAND ----------

df11.groupBy("Department").min("age").show()

# COMMAND ----------

df11.groupBy("Department").max("Age").show()

# COMMAND ----------

df11.groupBy("Department").avg("Salary").show()

# COMMAND ----------

df11.groupBy("Department").sum("Salary").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Aggregate functions
# MAGIC
# MAGIC - sum
# MAGIC - avg
# MAGIC - min
# MAGIC - max
# MAGIC - count

# COMMAND ----------

from pyspark.sql import functions as f 
df11.groupBy("Department").agg(f.sum("Salary")).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## join
# MAGIC
# MAGIC
# MAGIC df1.join(df2,on="id",how ="inner").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## drop

# COMMAND ----------

df11.drop("Age").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## distinct

# COMMAND ----------

df11.distinct().show()

# COMMAND ----------

df11.select("Department").distinct().show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## orderby (or) sort

# COMMAND ----------

df11.orderBy("Lastname",ascending=False).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Union
# MAGIC
# MAGIC   combines two dataframes with same schema into one dataframe
# MAGIC
# MAGIC df1.union(df2).show()

# COMMAND ----------

from pyspark.sql import Row
data = [Row(FacultyID =45, Firstname="Joseph",Lastname ="Ali Khan",Department ="Art",Age=78,Salary=678977)]
new_df =spark.createDataFrame(data)
df13=df11.union(new_df)
display(df13)

# COMMAND ----------

# MAGIC %md
# MAGIC # Columns

# COMMAND ----------

# MAGIC %md
# MAGIC ## Adding a new column

# COMMAND ----------

from pyspark.sql.functions import col
df11=df11.withColumn("Bonus",col("Salary")*0.05)
df11.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Adding Multiple Columns

# COMMAND ----------

# MAGIC %md
# MAGIC **lit()**
# MAGIC
# MAGIC The lit() function in PySpark is used to create a column with a constant or literal value. It is often used in conjunction with other column operations to add a constant value to a DataFrame.
# MAGIC ex:lit(""),lit("a")

# COMMAND ----------

from pyspark.sql.functions import col,concat,lit
df14= df11.withColumn("Fullname",concat(col("Firstname"),lit(" "),col("Lastname"))).withColumn("Amount",col("Salary")+col("bonus"))
display(df14)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Replacing the Exisiting column

# COMMAND ----------

replaced_col_values=df11.withColumn("Age",col("Age")+5)
display(replaced_col_values)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Renaming the Column Name

# COMMAND ----------

rename_col_name = df11.select(col("FacultyID").alias("ID"),col("Age").alias("years"))
display(rename_col_name)

# COMMAND ----------

renamed_withcolrename = df11.withColumnRenamed("FacultyID","P")
display(renamed_withcolrename)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Drop duplicates
# MAGIC
# MAGIC To drop duplicates in a PySpark DataFrame, you can use the dropDuplicates() method. This method can be used in two ways:
# MAGIC
# MAGIC **Without any arguments**: It drops rows that have the same values in all columns.
# MAGIC
# MAGIC **With column names as arguments**: It drops rows that have the same values in the specified columns.
# MAGIC

# COMMAND ----------

drop_dupli = df11.dropDuplicates(["Department"])
display(drop_dupli)

# COMMAND ----------

# MAGIC %md
# MAGIC limit

# COMMAND ----------

df11.limit(7).show()